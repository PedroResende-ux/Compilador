# Compilador Ada

## Trabalho Desenvolvido no Contexto da Unidade Curricular de Compiladores por:
- Helena Moutinho - 202304719
- Pedro Gulart - 202207418

---

## Descrição do Projeto

Este projeto implementa um compilador para um subconjunto da linguagem Ada. O compilador realiza as fases de:

1. **Análise Léxica** (Lexer) - Reconhecimento de tokens
2. **Análise Sintática** (Parser) - Construção da árvore sintática abstrata (AST)
3. **Visualização da AST** - Apresentação da árvore

O compilador aceita como entrada um programa Ada válido e produz como saída uma representação visual em árvore da estrutura sintática do programa.

---

## Funcionalidades Implementadas

### Lexer

Implementada usando Alex, o lexer reconhece:

#### Palavras-chave (case-insensitive):
- Estrutura de programa: `procedure`, `is`, `begin`, `end`
- Controlo de fluxo: `if`, `then`, `else`, `while`, `loop`
- Operadores lógicos: `and`, `or`, `not`
- Valores booleanos: `True`, `False`
- Operador aritmético: `mod`
- Input/Output: `Put_Line`, `Get_Line`

#### Operadores:
- **Aritméticos:** `+`, `-`, `*`, `/`, `mod`
- **Relacionais:** `=`, `/=`, `<`, `<=`, `>`, `>=`
- **Lógicos:** `and`, `or`, `not`
- **Atribuição:** `:=`

#### Literais:
- **Inteiros:** `42`, `0`, `123`
- **Strings:** `"Hello World"`, `"Ada"`
- **Booleanos:** `True`, `False`

#### Outros:
- **Identificadores:** variáveis (e.g., `x`, `counter`, `variable`)
- **Comentários:** linhas começadas por `--` (ignorados)
- **Pontuação:** `;`, `(`, `)`, `:`

---

### Parser

Implementada usando Happy, o parser reconhece:

#### Estrutura do Programa:
```ada
procedure Main is
begin
  -- comandos aqui
end Main;
```

O programa deve ser uma procedure chamada `Main`, e o nome no início e no fim devem coincidir.

#### Comandos Suportados:

1. **Atribuição:**
   ```ada
   x := 10;
   y := x + 5;
   ```

2. **Condicional (if-then-else):**
   ```ada
   if x > 5 then
     Put_Line("maior")
   else
     Put_Line("menor");
   ```

3. **Condicional sem else:**
   ```ada
   if x > 0 then
     Put_Line("positivo");
   ```

4. **Ciclo while:**
   ```ada
   while x < 10 loop
     x := x + 1
   end loop;
   ```

5. **Blocos:**
   ```ada
   begin
     x := 1;
     y := 2
   end;
   ```

6. **Output:**
   ```ada
   Put_Line("Hello World");
   Put_Line(x + y);
   ```

#### Expressões Suportadas:

- **Aritméticas:** `x + y`, `a * b - c`, `(x + y) / 2`
- **Relacionais:** `x > 5`, `a <= b`, `x = y`, `a /= b`
- **Lógicas:** `flag and (x > 0)`, `a or b`, `not flag`
- **Negação:** `-x`, `-(a + b)`
- **Módulo:** `x mod 3`
- **Input:** `Get_Line` (lê entrada do utilizador)
- **Parênteses:** `(x + y) * z`

#### Precedência de Operadores:
1. `:=` (atribuição)
2. `or`
3. `and`
4. `=`, `/=`, `<`, `<=`, `>`, `>=` (não-associativos)
5. `+`, `-`
6. `*`, `/`, `mod`
7. `not`, negação unária (`-`)

---

## Requisitos e Instalação

### Pré-requisitos

- **GHC** (Glasgow Haskell Compiler)
- **Alex** - gerador de analisadores léxicos
- **Happy** - gerador de analisadores sintáticos

### Instalação no Ubuntu/Debian

```bash
sudo apt install ghc
sudo apt install alex
sudo apt install happy

```

### Instalação no macOS (com Homebrew)

```bash
brew install ghc cabal-install
cabal update
cabal install alex happy
```

### Verificar instalação (deve mostrar versão como output)

```bash
ghc --version     
alex --version    
happy --version   
```

---

## Como Compilar

```bash
alex Lexer.x
happy Parser.y
ghc --make Main.hs -o compilador
```

---

## Como Executar

### Ler programa de um ficheiro:

```bash
./compilador test.ada
```

### Ler da entrada padrão:

```bash
./compilador < test.ada
```

ou

```bash
echo 'procedure Main is begin Put_Line("Hello") end Main;' | ./compilador
```

## Saída do Compilador

O compilador produz uma representação visual em árvore da AST:

Program
├─ Assignment
│  ├─ Variable: x
│  └─ IntLit: 10
├─ PutLine
│  └─ StringLit: "The value is:"
└─ PutLine
   └─ Var: x


---

## Exemplos de Programas

### Exemplo 1: Programa Simples

```ada
procedure Main is
begin
  x := 10;
  Put_Line("The value is:");
  Put_Line(x)
end Main;
```

### Exemplo 2: Condicional

```ada
procedure Main is
begin
  x := 5;
  if x > 0 then
    Put_Line("Positive")
  else
    Put_Line("Not positive");
end Main;
```

### Exemplo 3: Ciclo While

```ada
procedure Main is
begin
  counter := 0;
  while counter < 5 loop
    Put_Line("Counter:");
    Put_Line(counter);
    counter := counter + 1
  end loop;
  Put_Line("Done")
end Main;
```

### Exemplo 4: Expressões Complexas

```ada
procedure Main is
begin
  x := 10;
  y := 20;
  z := (x + y) * 2 - 5;
  
  if z > 50 and x < y then
    Put_Line("Complex condition is true");
  
  remainder := z mod 3;
  Put_Line(remainder)
end Main;
```

### Exemplo 5: Case-Insensitive

```ada
PROCEDURE Main IS
BEGIN
  x := 10;
  IF x > 5 THEN
    Put_Line("Greater")
  ELSE
    Put_Line("Smaller");
END Main;
```

---

## Limitações Conhecidas

1. **Não há análise semântica:**
   - Não verifica se variáveis foram declaradas
   - Não verifica tipos (pode somar string com inteiro na AST)
   - Não detecta variáveis não inicializadas

2. **Não há declaração de variáveis:**
   - O compilador assume que todas as variáveis usadas existem
   - Não há tipos explícitos

3. **Não há geração de código:**
   - O compilador apenas produz a AST
   - Não gera código executável ou código intermédio

4. **Estruturas não suportadas:**
   - Arrays
   - Records (structs)
   - Procedures/functions definidas pelo utilizador
   - Parâmetros
   - Tipos definidos pelo utilizador

