module AST where

data Program = Program [Stmt]
  deriving (Show, Eq)

-- Statements
data Stmt = 
    Assignment String Expr              -- x := expr
  | IfThenElse Expr Stmt Stmt          -- if expr then stmt else stmt
  | IfThen Expr Stmt                   -- if expr then stmt (sem else)
  | While Expr Stmt                    -- while expr loop stmt end loop
  | Block [Stmt]                       -- begin stmt1; stmt2; ... end
  | PutLine Expr                       -- Put_Line(expr)
  | EmptyStmt                         
  deriving (Show, Eq)

-- Expressões
data Expr = 
    -- Literais
    IntLit Int                         
  | BoolLit Bool                      
  | StringLit String                   
  | Var String                         
    
    -- Operações aritméticas
  | Add Expr Expr                      
  | Sub Expr Expr                      
  | Mul Expr Expr                     
  | Div Expr Expr                  
  | Mod Expr Expr                 
  | Neg Expr                       
    
    -- Operações booleanas
  | And Expr Expr                      
  | Or Expr Expr                      
  | Not Expr                           
    
    -- Operações relacionais
  | Eq Expr Expr                    
  | Neq Expr Expr                     
  | Lt Expr Expr                       
  | Lte Expr Expr                    
  | Gt Expr Expr                      
  | Gte Expr Expr                      
    
    -- Input
  | GetLine                            
  deriving (Show, Eq)